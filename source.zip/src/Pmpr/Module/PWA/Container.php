<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae9221c9fb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\PWA\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
