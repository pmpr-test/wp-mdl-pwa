<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0042c2475             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\PWA\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
