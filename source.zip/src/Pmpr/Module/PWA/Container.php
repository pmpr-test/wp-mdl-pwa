<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106708d71b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\PWA\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
